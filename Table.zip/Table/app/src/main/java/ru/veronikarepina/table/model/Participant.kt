package ru.veronikarepina.table.model

data class Participant(
    val name: String,
    val numberParticipant: String,
    var field1: String,
    var field2: String,
    var field3: String,
    var field4: String,
    var field5: String,
    var field6: String,
    var field7: String,
    var sum: String,
    var position: String
)
