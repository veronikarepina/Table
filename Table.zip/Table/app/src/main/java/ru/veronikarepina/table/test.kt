package ru.veronikarepina.table

fun main(){
    val list = listOf("1","2","")
    val sum = if(!(list.map { it.isNotEmpty() }.contains(false))) list.sumOf { it.toInt() } else 0
    println(sum)
}