package ru.veronikarepina.table.model

import ru.veronikarepina.table.FieldValue
import ru.veronikarepina.table.PersonNum

data class Person(
    val personNum: PersonNum,
    val fieldsValues: List<Pair<FieldValue, String>>,
    val score: String,
    val position: Int
)
