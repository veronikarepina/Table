package ru.veronikarepina.table.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.core.text.isDigitsOnly
import androidx.core.widget.addTextChangedListener
import androidx.core.widget.doOnTextChanged
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import ru.veronikarepina.table.FieldValue
import ru.veronikarepina.table.R
import ru.veronikarepina.table.databinding.TableRowBinding
import ru.veronikarepina.table.model.Participant
import ru.veronikarepina.table.model.Person


class Adapter(
    private val textChangeListener: (Person, Pair<FieldValue, String>) -> Unit
) : ListAdapter<Person, Adapter.NewsHolder>(Comparator) {

    private var firstTextWatcher1: TextWatcher? = null
    private var firstTextWatcher2: TextWatcher? = null
    private var firstTextWatcher3: TextWatcher? = null
    private var firstTextWatcher4: TextWatcher? = null
    private var firstTextWatcher5: TextWatcher? = null
    private var firstTextWatcher6: TextWatcher? = null
    private var firstTextWatcher7: TextWatcher? = null

    private object Comparator : DiffUtil.ItemCallback<Person>() {
        override fun areItemsTheSame(oldItem: Person, newItem: Person): Boolean {
            return oldItem.personNum == newItem.personNum
        }

        override fun areContentsTheSame(oldItem: Person, newItem: Person): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Adapter.NewsHolder {
        val itemBinding =
            TableRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NewsHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: Adapter.NewsHolder, position: Int) {
        holder.bind(getItem(position), textChangeListener)
    }

    inner class NewsHolder(private val binding: TableRowBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(
            item: Person,
            textChangeListener: (Person, Pair<FieldValue, String>) -> Unit
        ) = with(binding) {
            name.text = itemView.context.getString(item.personNum.personName)
            participantNumber.text = item.personNum.num.toString()
            score.text = item.score
            position.text = item.position.toString()

            item.fieldsValues.forEach {
                when (it.first) {
                    FieldValue.First -> {
                        field1.removeTextChangedListener(firstTextWatcher1)
                        field1.setText(it.second)
                    }
                    FieldValue.Second -> {
                        field2.removeTextChangedListener(firstTextWatcher2)
                        field2.setText(it.second)
                    }
                    FieldValue.Third -> {
                        field3.removeTextChangedListener(firstTextWatcher3)
                        field3.setText(it.second)
                    }
                    FieldValue.Fourth -> {
                        field4.removeTextChangedListener(firstTextWatcher4)
                        field4.setText(it.second)
                    }
                    FieldValue.Fifth -> {
                        field5.removeTextChangedListener(firstTextWatcher5)
                        field5.setText(it.second)
                    }
                    FieldValue.Six -> {
                        field6.removeTextChangedListener(firstTextWatcher6)
                        field6.setText(it.second)
                    }
                    FieldValue.Seven -> {
                        field7.removeTextChangedListener(firstTextWatcher7)
                        field7.setText(it.second)
                    }
                }
            }

            firstTextWatcher1 = field1.doOnTextChanged { text, _, _, _ ->
                val value = text?.toString()
                textChangeListener.invoke(item, FieldValue.First to value.orEmpty())
            }
            firstTextWatcher2 = field2.doOnTextChanged { text, _, _, _ ->
                val value = text?.toString()
                textChangeListener.invoke(item, FieldValue.Second to value.orEmpty())
            }
            firstTextWatcher3 = field3.doOnTextChanged { text, _, _, _ ->
                val value = text?.toString()
                textChangeListener.invoke(item, FieldValue.Third to value.orEmpty())
            }
            firstTextWatcher4 = field4.doOnTextChanged { text, _, _, _ ->
                val value = text?.toString()
                textChangeListener.invoke(item, FieldValue.Fourth to value.orEmpty())
            }
            firstTextWatcher5 = field5.doOnTextChanged { text, _, _, _ ->
                val value = text?.toString()
                textChangeListener.invoke(item, FieldValue.Fifth to value.orEmpty())
            }
            firstTextWatcher6 = field6.doOnTextChanged { text, _, _, _ ->
                val value = text?.toString()
                textChangeListener.invoke(item, FieldValue.Six to value.orEmpty())
            }
            firstTextWatcher7 = field7.doOnTextChanged { text, _, _, _ ->
                val value = text?.toString()
                textChangeListener.invoke(item, FieldValue.Seven to value.orEmpty())
            }

//            name.text = item.name
//            participantNumber.text = item.numberParticipant
//
//            val fields = listOf(field1, field2, field3, field4, field5, field6, field7)
//            val fieldsStrings = mutableListOf(item.field1, item.field2, item.field3,
//                item.field4, item.field5, item.field6, item.field7)
//            val digits = listOf("0", "1", "2", "3", "4", "5")
//            for((index, field) in fieldsStrings.withIndex())
//                if(field == "0"){
//                    fields[index].setBackgroundColor(Color.BLACK)
//                    fields[index].isFocusable = false
//                }
//            field1.addTextChangedListener {
//                if(field1.text.toString() == ""){
//                    item.field1 = ""
//                    fieldsStrings[0] = item.field1
//                    setScore(fieldsStrings, item)
//                }
//                else if (field1.text.toString() in digits){
//                    item.field1 = field1.text.toString()
//                    fieldsStrings[0] = item.field1
//                    setScore(fieldsStrings, item)
//                }
//                else {
//                    field1.setTextColor(Color.RED)
//                    Toast.makeText(context, context.getString(R.string.error), Toast.LENGTH_SHORT).show()
//                    score.text = ""
//                }
//            }
//            field2.addTextChangedListener {
//                if(field2.text.toString() == ""){
//                    item.field2 = ""
//                    fieldsStrings[1] = item.field2
//                    setScore(fieldsStrings, item)
//                }
//                else if (field2.text.toString() in digits){
//                    item.field2 = field2.text.toString()
//                    fieldsStrings[1] = item.field2
//                    setScore(fieldsStrings, item)
//                }
//                else {
//                    field2.setTextColor(Color.RED)
//                    Toast.makeText(context, context.getString(R.string.error), Toast.LENGTH_SHORT).show()
//                    score.text = ""
//                    item.field2 = ""
//                }
//            }
//            field3.addTextChangedListener {
//                if(field3.text.toString() == ""){
//                    item.field3 = ""
//                    fieldsStrings[2] = item.field3
//                    setScore(fieldsStrings, item)
//                }
//                else if (field3.text.toString() in digits){
//                    item.field3 = field3.text.toString()
//                    fieldsStrings[2] = item.field3
//                    setScore(fieldsStrings, item)
//                }
//                else {
//                    field3.setTextColor(Color.RED)
//                    Toast.makeText(context, context.getString(R.string.error), Toast.LENGTH_SHORT).show()
//                    score.text = ""
//                }
//            }
//            field4.addTextChangedListener {
//                if(field4.text.toString() == ""){
//                    item.field4 = ""
//                    fieldsStrings[3] = item.field4
//                    setScore(fieldsStrings, item)
//                }
//                else if (field4.text.toString() in digits){
//                    item.field4 = field4.text.toString()
//                    fieldsStrings[3] = item.field4
//                    setScore(fieldsStrings, item)
//                }
//                else {
//                    field4.setTextColor(Color.RED)
//                    Toast.makeText(context, context.getString(R.string.error), Toast.LENGTH_SHORT).show()
//                    score.text = ""
//                }
//            }
//            field5.addTextChangedListener {
//                if(field5.text.toString() == ""){
//                    item.field5 = ""
//                    fieldsStrings[4] = item.field5
//                    setScore(fieldsStrings, item)
//                }
//                else if (field5.text.toString() in digits){
//                    item.field5 = field5.text.toString()
//                    fieldsStrings[4] = item.field5
//                    setScore(fieldsStrings, item)
//                }
//                else {
//                    field5.setTextColor(Color.RED)
//                    Toast.makeText(context, context.getString(R.string.error), Toast.LENGTH_SHORT).show()
//                    score.text = ""
//                }
//            }
//            field6.addTextChangedListener {
//                if(field6.text.toString() == ""){
//                    item.field6 = ""
//                    fieldsStrings[5] = item.field6
//                    setScore(fieldsStrings, item)
//                }
//                else if (field6.text.toString() in digits){
//                    item.field6 = field6.text.toString()
//                    fieldsStrings[5] = item.field6
//                    setScore(fieldsStrings, item)
//                }
//                else {
//                    field6.setTextColor(Color.RED)
//                    Toast.makeText(context, context.getString(R.string.error), Toast.LENGTH_SHORT).show()
//                    score.text = ""
//                }
//            }
//            field7.addTextChangedListener {
//                if(field7.text.toString() == ""){
//                    item.field7 = ""
//                    fieldsStrings[6] = item.field7
//                    setScore(fieldsStrings, item, sumList, pos)
//                }
//                else if (field7.text.toString() in digits){
//                    item.field7 = field7.text.toString()
//                    fieldsStrings[6] = item.field7
//                    setScore(fieldsStrings, item)
//                }
//                else {
//                    field7.setTextColor(Color.RED)
//                    Toast.makeText(context, context.getString(R.string.error), Toast.LENGTH_SHORT).show()
//                    score.text = ""
//                }
//            }
//            score.addTextChangedListener {
//                Log.d("MyLog", "im here")
//                item.position = item.sum
//                Log.d("MyLog", "position: ${item.position}")
//                position.text = item.position
//            }
//            //position.text = if (item.sum.isNotEmpty()) item.sum else item.position
//            //position.text = item.position
//        }
//        private fun setScore(fieldsStrings: List<String>, item: Participant, sumList: List<String>, pos: Int){
//            binding.score.text = if(!(fieldsStrings.map { it.isNotEmpty() }.contains(false)))
//                fieldsStrings.sumOf { it.toInt() }.toString()  else ""
//            Log.d("MyLog", "fields: $fieldsStrings")
//            item.sum = binding.score.text.toString()
//            Log.d("MyLog", "item: $item")
//
//            sumList[pos] = binding.score.text.toString()
//        }
//        private fun checkValue(value: String){
//
//        }
        }
    }
}

//inline fun EditText.onTextChange(crossinline listener: (String) -> Unit) {
//    this.addTextChangedListener(object: TextWatcher {
//        override fun beforeTextChanged(charSequence: CharSequence?, p1: Int, p2: Int, p3: Int) {}
//
//        override fun onTextChanged(charSequence: CharSequence?, p1: Int, p2: Int, p3: Int) {
//            listener(charSequence.toString())
//        }
//
//        override fun afterTextChanged(p0: Editable?) {}
//    })
//}