package ru.veronikarepina.table

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import ru.veronikarepina.table.model.Person

class MainViewModel : ViewModel() {

    private val _personsList = MutableLiveData<List<Person>>()
    val personList: LiveData<List<Person>> = _personsList

    private val valuesMap = mutableMapOf<PersonNum, List<Pair<FieldValue, String>>>()

    init {
        _personsList.value = generateList()
        initMap()
    }

    fun setFieldValue(person: Person, value: Pair<FieldValue, String>) {
        val newList = mutableListOf<Person>()
        val oldList = _personsList.value?.toMutableList()
        oldList?.forEach { item ->
            newList.add(
                if (person.personNum == item.personNum) {
                    item.copy(
                        fieldsValues = item.fieldsValues.map {
                            it.copy(
                                second = if (it.first == value.first) {
                                    value.second
                                } else {
                                    it.second
                                }
                            )
                        }
                    )
                } else {
                    item
                }
            )
        }

        _personsList.value = newList
    }

    private fun initMap() {
        _personsList.value?.forEach {
            valuesMap[it.personNum] = it.fieldsValues
        }
    }

    private fun generateList(): List<Person> {
        return PersonNum.values().mapIndexed { index, personNum ->
            Person(personNum, FieldValue.values().map { it to "" }, "", 0)
        }
    }


}

enum class PersonNum(val personName: Int, val num: Int) {
    First(R.string.participant1, 1), Second(R.string.participant2, 2), Third(
        R.string.participant3,
        3
    ),
    Fourth(R.string.participant4, 4), Fifth(R.string.participant5, 5), Six(
        R.string.participant6,
        6
    ),
    Seven(R.string.participant7, 7)
}

enum class FieldValue {
    First, Second, Third, Fourth, Fifth, Six, Seven
}