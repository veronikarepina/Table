package ru.veronikarepina.table

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ru.veronikarepina.table.adapter.Adapter
import ru.veronikarepina.table.databinding.ActivityMainBinding
import ru.veronikarepina.table.model.Participant

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel = MainViewModel()
    private val adapter: Adapter by lazy {
        Adapter { person, value ->
            viewModel.setFieldValue(person, value)
        }
    }
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycler.adapter = adapter

        viewModel.personList.observe(this) {
            adapter.submitList(it.toMutableList())
        }

    }
}