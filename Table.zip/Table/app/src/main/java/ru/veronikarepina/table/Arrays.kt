package ru.veronikarepina.table

class Arrays {
    companion object{
        val arrayNames = arrayOf(R.string.participant1, R.string.participant2, R.string.participant3,
        R.string.participant4, R.string.participant5, R.string.participant6, R.string.participant7)
        val arrayNumbers = arrayOf(R.string.one, R.string.two, R.string.three, R.string.four,
        R.string.five, R.string.six, R.string.seven)
    }
}